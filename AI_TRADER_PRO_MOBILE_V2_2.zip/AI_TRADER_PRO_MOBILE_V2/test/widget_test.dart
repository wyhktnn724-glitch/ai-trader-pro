import 'package:flutter_test/flutter_test.dart';
import 'package:ai_trader_pro_mobile/src/candle_chart.dart';
import 'package:ai_trader_pro_mobile/src/models.dart';
import 'package:flutter/material.dart';

void main() {
  testWidgets('candlestick chart renders empty state', (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(body: CandleChart(candles: <Candle>[])),
    ));
    expect(find.text('داده نمودار موجود نیست'), findsOneWidget);
  });
}
