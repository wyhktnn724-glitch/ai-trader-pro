import 'package:flutter/material.dart';
import 'src/dashboard.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AiTraderApp());
}

class AiTraderApp extends StatelessWidget {
  const AiTraderApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'AI Trader Pro',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF43A6FF),
            brightness: Brightness.dark,
          ),
          scaffoldBackgroundColor: const Color(0xFF08111F),
          cardColor: const Color(0xFF111F32),
          useMaterial3: true,
          fontFamily: 'Roboto',
        ),
        home: const TraderDashboard(),
      );
}
