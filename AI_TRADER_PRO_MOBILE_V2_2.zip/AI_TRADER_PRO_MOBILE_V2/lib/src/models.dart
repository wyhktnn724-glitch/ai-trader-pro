class Candle {
  final DateTime time;
  final double open, high, low, close, volume;
  const Candle({
    required this.time,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    this.volume = 0,
  });
}

class Analysis {
  final String timeframe;
  final String direction;
  final double score, close, rsi, emaFast, emaSlow, macd, macdSignal, atr, adx;
  final double support, resistance;
  final List<String> reasons;
  const Analysis({
    required this.timeframe,
    required this.direction,
    required this.score,
    required this.close,
    required this.rsi,
    required this.emaFast,
    required this.emaSlow,
    required this.macd,
    required this.macdSignal,
    required this.atr,
    required this.adx,
    required this.support,
    required this.resistance,
    required this.reasons,
  });
}

class TradeSignal {
  final String symbol, timeframe, direction;
  final int strength;
  final double? entry, stopLoss, takeProfit;
  final Map<String, Analysis> analyses;
  final List<String> reasons;
  final DateTime generatedAt;
  const TradeSignal({
    required this.symbol,
    required this.timeframe,
    required this.direction,
    required this.strength,
    required this.entry,
    required this.stopLoss,
    required this.takeProfit,
    required this.analyses,
    required this.reasons,
    required this.generatedAt,
  });

  Map<String, dynamic> toJson() => {
    'symbol': symbol, 'timeframe': timeframe, 'direction': direction,
    'strength': strength, 'entry': entry, 'stopLoss': stopLoss,
    'takeProfit': takeProfit, 'generatedAt': generatedAt.toIso8601String(),
  };
}
