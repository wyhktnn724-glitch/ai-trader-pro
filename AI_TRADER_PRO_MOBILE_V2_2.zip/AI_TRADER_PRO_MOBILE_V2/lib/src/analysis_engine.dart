import 'dart:math' as math;
import 'models.dart';

class AnalysisEngine {
  double _ema(List<double> values, int period) {
    if (values.isEmpty) return 0;
    final alpha = 2 / (period + 1);
    var result = values.first;
    for (final value in values.skip(1)) {
      result = alpha * value + (1 - alpha) * result;
    }
    return result;
  }

  List<double> _emaSeries(List<double> values, int period) {
    final out = <double>[];
    final alpha = 2 / (period + 1);
    var value = values.first;
    out.add(value);
    for (final x in values.skip(1)) {
      value = alpha * x + (1 - alpha) * value;
      out.add(value);
    }
    return out;
  }

  double _rsi(List<double> close, [int period = 14]) {
    if (close.length <= period) return 50;
    var gain = 0.0, loss = 0.0;
    for (var i = close.length - period; i < close.length; i++) {
      final d = close[i] - close[i - 1];
      if (d > 0) gain += d; else loss -= d;
    }
    gain /= period;
    loss /= period;
    if (loss == 0) return gain == 0 ? 50 : 100;
    return 100 - 100 / (1 + gain / loss);
  }

  ({double k, double d}) _stochastic(List<Candle> candles, {int period = 14}) {
    final slice = candles.skip(candles.length - period);
    final high = slice.map((c) => c.high).reduce((a, b) => math.max(a, b).toDouble());
    final low = slice.map((c) => c.low).reduce((a, b) => math.min(a, b).toDouble());
    final k = high == low ? 50.0 : 100 * (candles.last.close - low) / (high - low);
    // A smoothed proxy; the full %D history is not needed for this snapshot.
    return (k: k, d: k);
  }

  ({double middle, double upper, double lower}) _bollinger(
      List<double> close, {int period = 20}) {
    final values = close.skip(close.length - period).toList();
    final mean = values.reduce((a, b) => a + b) / period;
    final variance = values.map((v) => math.pow(v - mean, 2).toDouble())
        .reduce((a, b) => a + b) / period;
    final sd = math.sqrt(variance);
    return (middle: mean, upper: mean + 2 * sd, lower: mean - 2 * sd);
  }

  ({double atr, double adx, double plusDi, double minusDi}) _directional(
      List<Candle> candles, {int period = 14}) {
    var trSum = 0.0, plusSum = 0.0, minusSum = 0.0;
    final start = math.max(1, candles.length - period);
    for (var i = start; i < candles.length; i++) {
      final c = candles[i], p = candles[i - 1];
      final tr = math.max(c.high - c.low,
          math.max((c.high - p.close).abs(), (c.low - p.close).abs()));
      final up = c.high - p.high;
      final down = p.low - c.low;
      trSum += tr;
      if (up > down && up > 0) plusSum += up;
      if (down > up && down > 0) minusSum += down;
    }
    final n = candles.length - start;
    final atr = trSum / n;
    final plus = atr == 0 ? 0.0 : 100 * (plusSum / n) / atr;
    final minus = atr == 0 ? 0.0 : 100 * (minusSum / n) / atr;
    final dx = plus + minus == 0 ? 0.0 : 100 * (plus - minus).abs() / (plus + minus);
    return (atr: atr, adx: dx, plusDi: plus, minusDi: minus);
  }

  Analysis analyse(List<Candle> candles, String timeframe) {
    if (candles.length < 60) {
      throw Exception('$timeframe: حداقل ۶۰ کندل معتبر لازم است.');
    }
    for (final c in candles) {
      if (![c.open, c.high, c.low, c.close].every((v) => v.isFinite && v > 0) ||
          c.high < math.max(c.open, c.close) ||
          c.low > math.min(c.open, c.close) ||
          c.high < c.low) {
        throw Exception('داده OHLC نامعتبر است.');
      }
    }
    final close = candles.map((c) => c.close).toList();
    final fastSeries = _emaSeries(close, 20);
    final slowSeries = _emaSeries(close, 50);
    final fast = fastSeries.last, slow = slowSeries.last;
    final rsi = _rsi(close);
    final macdHistory = <double>[];
    for (var i = 25; i < close.length; i++) {
      final sub = close.sublist(0, i + 1);
      macdHistory.add(_ema(sub, 12) - _ema(sub, 26));
    }
    final macdSignalSeries = _emaSeries(macdHistory, 9);
    final macd = macdHistory.last, macdSignal = macdSignalSeries.last;
    final directional = _directional(candles);
    final stoch = _stochastic(candles);
    final bands = _bollinger(close);
    final recent = candles.skip(candles.length - 20).toList();
    final previous = candles.skip(candles.length - 40).take(20).toList();
    final resistance = recent.map((c) => c.high).reduce((a, b) => math.max(a, b).toDouble());
    final support = recent.map((c) => c.low).reduce((a, b) => math.min(a, b).toDouble());
    final priorHigh = previous.map((c) => c.high).reduce((a, b) => math.max(a, b).toDouble());
    final priorLow = previous.map((c) => c.low).reduce((a, b) => math.min(a, b).toDouble());
    final last = candles.last;
    final prev = candles[candles.length - 2];

    var score = 0.0;
    final reasons = <String>[];
    if (fast > slow) { score += 1.5; reasons.add('روند EMA20 بالاتر از EMA50 است.'); }
    else { score -= 1.5; reasons.add('روند EMA20 پایین‌تر از EMA50 است.'); }
    if (fastSeries.length > 2 && fastSeries.last > fastSeries[fastSeries.length - 3]) score += .5;
    if (fastSeries.length > 2 && fastSeries.last < fastSeries[fastSeries.length - 3]) score -= .5;
    if (rsi > 55 && rsi < 72) { score += 1; reasons.add('RSI مومنتوم صعودی دارد.'); }
    else if (rsi < 45 && rsi > 28) { score -= 1; reasons.add('RSI مومنتوم نزولی دارد.'); }
    else if (rsi >= 72) reasons.add('RSI در محدوده اشباع خرید است؛ ورود تعقیبی پرریسک است.');
    else if (rsi <= 28) reasons.add('RSI در محدوده اشباع فروش است؛ احتمال برگشت را بررسی کنید.');
    if (macd > macdSignal && macd > 0) { score += 1; reasons.add('MACD صعودی و بالای خط صفر است.'); }
    else if (macd < macdSignal && macd < 0) { score -= 1; reasons.add('MACD نزولی و زیر خط صفر است.'); }
    if (directional.plusDi > directional.minusDi) score += .75;
    else if (directional.minusDi > directional.plusDi) score -= .75;
    if (last.high > priorHigh && last.low > priorLow) { score += 1; reasons.add('ساختار قیمت HH/HL صعودی است.'); }
    else if (last.high < priorHigh && last.low < priorLow) { score -= 1; reasons.add('ساختار قیمت LH/LL نزولی است.'); }
    if (last.close > bands.middle && last.close < bands.upper) score += .25;
    if (last.close < bands.middle && last.close > bands.lower) score -= .25;
    if (last.close > last.open && prev.close < prev.open &&
        last.close > prev.open && last.open < prev.close) {
      score += .75; reasons.add('الگوی Bullish Engulfing دیده شد.');
    } else if (last.close < last.open && prev.close > prev.open &&
        last.close < prev.open && last.open > prev.close) {
      score -= .75; reasons.add('الگوی Bearish Engulfing دیده شد.');
    }
    if (directional.adx < 16) {
      score *= .75;
      reasons.add('ADX پایین است؛ روند قدرت کافی ندارد.');
    } else if (directional.adx > 25) {
      reasons.add('قدرت روند با ADX تأیید نسبی می‌شود.');
    }
    final direction = score >= 2.25 ? 'BUY' : score <= -2.25 ? 'SELL' : 'WAIT';
    return Analysis(
      timeframe: timeframe, direction: direction, score: score,
      close: close.last, rsi: rsi, emaFast: fast, emaSlow: slow,
      macd: macd, macdSignal: macdSignal, atr: directional.atr,
      adx: directional.adx, support: support, resistance: resistance,
      reasons: [...reasons,
        'Stochastic %K: ${stoch.k.toStringAsFixed(1)}',
        'Bollinger: ${bands.lower.toStringAsFixed(5)} – ${bands.upper.toStringAsFixed(5)}',
      ],
    );
  }

  TradeSignal combine({
    required String symbol,
    required String timeframe,
    required Map<String, List<Candle>> candlesByTf,
  }) {
    final analyses = <String, Analysis>{};
    for (final entry in candlesByTf.entries) {
      analyses[entry.key] = analyse(entry.value, entry.key);
    }
    final primary = analyses[timeframe];
    if (primary == null) throw Exception('داده تایم‌فریم اصلی موجود نیست.');
    const rank = {'M1': 1, 'M5': 2, 'M15': 3, 'M30': 4, 'H1': 5, 'H4': 6, 'D1': 7};
    final higher = analyses.entries
        .where((e) => (rank[e.key] ?? 0) > (rank[timeframe] ?? 0))
        .map((e) => e.value).toList();
    final weights = <String, double>{
      'M1': .25, 'M5': .25, 'M15': .20, 'M30': .15,
      'H1': .30, 'H4': .25, 'D1': .15,
    };
    var weighted = 0.0, total = 0.0;
    for (final e in analyses.entries) {
      final w = weights[e.key] ?? .15;
      weighted += e.value.score * w;
      total += w;
    }
    weighted = total == 0 ? 0 : weighted / total;
    final buyVotes = higher.where((a) => a.direction == 'BUY').length;
    final sellVotes = higher.where((a) => a.direction == 'SELL').length;
    final direction = weighted >= 2 && (higher.isEmpty || buyVotes > 0)
        ? 'BUY'
        : weighted <= -2 && (higher.isEmpty || sellVotes > 0) ? 'SELL' : 'WAIT';
    final strength = direction == 'WAIT'
        ? (50 + weighted.abs() * 3).clamp(50, 68).round()
        : (52 + weighted.abs() * 6 + 5 *
            (direction == 'BUY' ? buyVotes : sellVotes)).clamp(52, 92).round();
    final entry = direction == 'WAIT' ? null : primary.close;
    final stop = entry == null ? null :
        direction == 'BUY' ? entry - primary.atr * 1.5 : entry + primary.atr * 1.5;
    final target = entry == null ? null :
        direction == 'BUY' ? entry + primary.atr * 2.5 : entry - primary.atr * 2.5;
    return TradeSignal(
      symbol: symbol, timeframe: timeframe, direction: direction,
      strength: strength, entry: entry, stopLoss: stop, takeProfit: target,
      analyses: analyses,
      reasons: [
        'امتیاز وزن‌دار چندتایم‌فریمی: ${weighted.toStringAsFixed(2)}',
        'تأیید تایم‌فریم بالاتر: ${higher.length} مورد.',
        ...primary.reasons,
        if (direction == 'WAIT') 'شرایط ورود کافی نیست؛ از معامله اجباری خودداری کنید.',
      ],
      generatedAt: DateTime.now(),
    );
  }
}
