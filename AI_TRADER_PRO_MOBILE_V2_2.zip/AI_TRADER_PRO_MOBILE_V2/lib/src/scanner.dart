import 'analysis_engine.dart';
import 'market_data.dart';
import 'models.dart';

class ScanItem {
  final String symbol;
  final String direction;
  final int strength;
  final double price;
  const ScanItem(this.symbol, this.direction, this.strength, this.price);
}

class MarketScanner {
  final MarketDataService data;
  final AnalysisEngine engine;
  MarketScanner(this.data, this.engine);

  Future<List<ScanItem>> scan(List<String> symbols, String timeframe,
      {String twelveDataKey = ''}) async {
    final results = <ScanItem>[];
    for (final symbol in symbols) {
      try {
        final candles = await data.fetch(
          symbol: symbol, timeframe: timeframe, twelveDataKey: twelveDataKey,
        );
        final analysis = engine.analyse(candles, timeframe);
        final strength = (50 + analysis.score.abs() * 8).clamp(50, 90).round();
        results.add(ScanItem(symbol, analysis.direction, strength, analysis.close));
      } catch (_) {
        // Keep scanner resilient; unavailable symbols are skipped.
      }
    }
    results.sort((a, b) => b.strength.compareTo(a.strength));
    return results;
  }
}
