import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'analysis_engine.dart';
import 'market_data.dart';
import 'models.dart';
import 'scanner.dart';
import 'backtest.dart';
import 'candle_chart.dart';

class TraderDashboard extends StatefulWidget {
  const TraderDashboard({super.key});
  @override
  State<TraderDashboard> createState() => _TraderDashboardState();
}

class _TraderDashboardState extends State<TraderDashboard> {
  final _market = MarketDataService();
  final _engine = AnalysisEngine();
  final _secure = const FlutterSecureStorage();
  final _symbols = ['XAUUSD', 'EURUSD', 'GBPUSD', 'USDJPY', 'BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT'];
  final _frames = ['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D1'];
  String _symbol = 'BTCUSDT', _timeframe = 'M5';
  String _apiKey = '';
  String _status = 'برای شروع، دکمه تحلیل بازار را بزنید.';
  bool _busy = false;
  TradeSignal? _signal;
  List<String> _history = [];
  List<Candle> _chartCandles = [];

  @override
  void initState() {
    super.initState();
    _loadLocal();
  }

  Future<void> _loadLocal() async {
    final prefs = await SharedPreferences.getInstance();
    final key = await _secure.read(key: 'twelvedata_key') ?? '';
    if (!mounted) return;
    setState(() {
      _apiKey = key;
      _history = prefs.getStringList('signal_history') ?? [];
      _status = 'آماده؛ موتور تحلیل روی همین موبایل اجرا می‌شود.';
    });
  }

  Future<void> _analyse() async {
    if (_busy) return;
    setState(() { _busy = true; _status = 'در حال دریافت داده و تحلیل چندتایم‌فریمی…'; });
    try {
      final frames = <String>[ _timeframe ];
      const rank = {'M1': 1, 'M5': 2, 'M15': 3, 'M30': 4, 'H1': 5, 'H4': 6, 'D1': 7};
      final targetRank = rank[_timeframe] ?? 2;
      final higher = _frames.where((f) => (rank[f] ?? 0) > targetRank).take(2);
      frames.addAll(higher);
      if (higher.isEmpty) {
        final lower = _frames.where((f) => (rank[f] ?? 0) < targetRank).toList();
        if (lower.isNotEmpty) frames.add(lower.last);
      }
      final result = <String, List<Candle>>{};
      for (final frame in frames) {
        result[frame] = await _market.fetch(
          symbol: _symbol, timeframe: frame, twelveDataKey: _apiKey,
        );
      }
      final signal = _engine.combine(
        symbol: _symbol, timeframe: _timeframe, candlesByTf: result,
      );
      final prefs = await SharedPreferences.getInstance();
      final history = prefs.getStringList('signal_history') ?? [];
      history.insert(0, jsonEncode(signal.toJson()));
      if (history.length > 50) history.removeRange(50, history.length);
      await prefs.setStringList('signal_history', history);
      if (!mounted) return;
      setState(() {
        _signal = signal;
        _chartCandles = result[_timeframe] ?? [];
        _history = history;
        _status = 'تحلیل انجام شد • ${DateTime.now().toLocal()}';
      });
    } catch (e) {
      if (mounted) setState(() => _status = 'خطا: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _scanMarket() async {
    if (_busy) return;
    setState(() { _busy = true; _status = 'در حال اسکن نمادها…'; });
    try {
      final items = await MarketScanner(_market, _engine).scan(
        _symbols, _timeframe, twelveDataKey: _apiKey,
      );
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('نتیجه اسکن بازار'),
        content: SizedBox(width: double.maxFinite, child: items.isEmpty
          ? const Text('داده‌ای دریافت نشد؛ اتصال یا API Key را بررسی کنید.')
          : ListView(shrinkWrap: true, children: items.map((x) => ListTile(
              dense: true, title: Text(x.symbol),
              subtitle: Text('قیمت: ${_fmt(x.price)} • قدرت: ${x.strength}/100'),
              trailing: Text(x.direction, style: TextStyle(
                color: _color(x.direction), fontWeight: FontWeight.bold)),
            )).toList())),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('بستن'))],
      ));
      if (mounted) setState(() => _status = 'اسکن تمام شد؛ ${items.length} نماد بررسی شد.');
    } catch (e) {
      if (mounted) setState(() => _status = 'خطای اسکن: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _runBacktest() async {
    if (_busy) return;
    setState(() { _busy = true; _status = 'در حال دریافت تاریخچه و اجرای بک‌تست…'; });
    try {
      final candles = await _market.fetch(
        symbol: _symbol, timeframe: _timeframe, twelveDataKey: _apiKey);
      final result = Backtester(_engine).run(candles, _timeframe);
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
        title: Text('بک‌تست $_symbol • $_timeframe'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          _statMetric('تعداد معاملات', '${result.trades}'),
          const SizedBox(height: 8),
          _statMetric('برد / باخت', '${result.wins} / ${result.losses}'),
          const SizedBox(height: 8),
          _statMetric('Win rate', '${result.winRate.toStringAsFixed(1)}%'),
          const SizedBox(height: 8),
          _statMetric('بازده خالص', '${result.netReturnPct.toStringAsFixed(2)}%'),
          const SizedBox(height: 8),
          _statMetric('Profit factor', result.profitFactor.isInfinite ? '∞' : result.profitFactor.toStringAsFixed(2)),
          const SizedBox(height: 8),
          _statMetric('حداکثر افت سرمایه', '${result.maxDrawdownPct.toStringAsFixed(2)}%'),
          const SizedBox(height: 8),
          _statMetric('میانگین هر معامله', '${result.averageTradePct.toStringAsFixed(3)}%'),
          const SizedBox(height: 8),
          Text('هزینه تخمینی معاملات: ${result.feesPct.toStringAsFixed(2)}% از سرمایه اولیه',
            style: const TextStyle(color: Colors.white60, fontSize: 12)),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('بستن'))],
      ));
      if (mounted) setState(() => _status = 'بک‌تست تمام شد؛ ${result.trades} معامله شبیه‌سازی شد.');
    } catch (e) {
      if (mounted) setState(() => _status = 'خطای بک‌تست: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _settings() async {
    final controller = TextEditingController(text: _apiKey);
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تنظیمات منبع داده'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('برای نمادهای Forex و طلا، کلید API سرویس Twelve Data لازم است. رمزارزهای فهرست‌شده از API عمومی Binance دریافت می‌شوند.'),
          const SizedBox(height: 12),
          TextField(
            controller: controller, obscureText: true,
            decoration: const InputDecoration(labelText: 'Twelve Data API Key', border: OutlineInputBorder()),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('لغو')),
          FilledButton(onPressed: () async {
            _apiKey = controller.text.trim();
            await _secure.write(key: 'twelvedata_key', value: _apiKey);
            if (mounted) setState(() {});
            if (context.mounted) Navigator.pop(context);
          }, child: const Text('ذخیره امن')),
        ],
      ),
    );
    controller.dispose();
  }

  Color _color(String direction) => direction == 'BUY'
      ? const Color(0xFF37D99A)
      : direction == 'SELL' ? const Color(0xFFFF657A) : const Color(0xFFFFC45C);

  String _fmt(num? n) => n == null ? '—' : n.toStringAsFixed(n.abs() >= 100 ? 2 : 5);

  Widget _card(Widget child) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(padding: const EdgeInsets.all(16), child: child),
  );

  Widget _statMetric(String label, String value) => Container(
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(
      color: const Color(0xFF0A1728),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: const Color(0xFF243954)),
    ),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12)),
      const SizedBox(width: 12),
      Flexible(child: Text(value, textAlign: TextAlign.end,
        style: const TextStyle(fontWeight: FontWeight.bold))),
    ]),
  );

  Widget _metric(String label, String value) => Expanded(
    child: Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0A1728),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF243954)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: Colors.white60, fontSize: 11)),
        const SizedBox(height: 6),
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
      ]),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final signal = _signal;
    final primary = signal?.analyses[_timeframe];
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI TRADER PRO', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
        actions: [
          IconButton(onPressed: _settings, icon: const Icon(Icons.settings_outlined), tooltip: 'تنظیمات'),
          IconButton(onPressed: _busy ? null : _analyse, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(14), children: [
        _card(Row(children: [
          const Icon(Icons.phone_android, color: Color(0xFF37D99A)),
          const SizedBox(width: 10),
          Expanded(child: Text('Standalone Mobile Engine\nبدون Python، Backend یا کامپیوتر شخصی',
            style: TextStyle(color: Colors.white.withOpacity(.85), fontSize: 13))),
          const Chip(label: Text('LOCAL')),
        ])),
        _card(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('بازار و تایم‌فریم', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: DropdownButtonFormField<String>(
              value: _symbol, isExpanded: true,
              decoration: const InputDecoration(labelText: 'نماد', border: OutlineInputBorder()),
              items: _symbols.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
              onChanged: (v) => setState(() => _symbol = v ?? _symbol),
            )),
            const SizedBox(width: 10),
            Expanded(child: DropdownButtonFormField<String>(
              value: _timeframe, isExpanded: true,
              decoration: const InputDecoration(labelText: 'تایم‌فریم', border: OutlineInputBorder()),
              items: _frames.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
              onChanged: (v) => setState(() => _timeframe = v ?? _timeframe),
            )),
          ]),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _busy ? null : _analyse,
            icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.analytics_outlined),
            label: Text(_busy ? 'در حال تحلیل…' : 'تحلیل بازار'),
          ),
          const SizedBox(height: 8),
          Text(_status, textDirection: TextDirection.rtl, style: const TextStyle(color: Colors.white60, fontSize: 12)),
        ])),
        _card(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('ابزارهای حرفه‌ای', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: _busy ? null : _scanMarket,
              icon: const Icon(Icons.radar), label: const Text('اسکنر بازار'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(
              onPressed: _busy ? null : _runBacktest,
              icon: const Icon(Icons.query_stats), label: const Text('بک‌تست'))),
          ]),
        ])),
        if (signal != null) ...[
          _card(Column(children: [
            Text('${signal.symbol} • ${signal.timeframe}', style: const TextStyle(color: Colors.white60)),
            const SizedBox(height: 8),
            Text(signal.direction, style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: _color(signal.direction))),
            Text('شاخص قدرت سیگنال: ${signal.strength}/100', style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 14),
            Row(children: [
              _metric('ENTRY', _fmt(signal.entry)),
              const SizedBox(width: 8),
              _metric('STOP LOSS', _fmt(signal.stopLoss)),
              const SizedBox(width: 8),
              _metric('TAKE PROFIT', _fmt(signal.takeProfit)),
            ]),
          ])),
          _card(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('نمودار کندلی • ۶۰ کندل بسته‌شده', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            CandleChart(candles: _chartCandles),
          ])),
          _card(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('اندیکاتورها', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: [
              _pill('RSI', _fmt(primary?.rsi)),
              _pill('EMA 20', _fmt(primary?.emaFast)),
              _pill('EMA 50', _fmt(primary?.emaSlow)),
              _pill('MACD', _fmt(primary?.macd)),
              _pill('ATR', _fmt(primary?.atr)),
              _pill('ADX', _fmt(primary?.adx)),
              _pill('SUPPORT', _fmt(primary?.support)),
              _pill('RESISTANCE', _fmt(primary?.resistance)),
            ]),
          ])),
          _card(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('تحلیل چندتایم‌فریمی', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...signal.analyses.entries.map((e) => ListTile(
              dense: true, contentPadding: EdgeInsets.zero,
              title: Text(e.key), subtitle: Text('Score: ${e.value.score.toStringAsFixed(2)}'),
              trailing: Text(e.value.direction, style: TextStyle(color: _color(e.value.direction), fontWeight: FontWeight.bold)),
            )),
          ])),
          _card(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('دلایل سیگنال', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...signal.reasons.map((r) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('•  ', style: TextStyle(color: Color(0xFF43A6FF))),
                Expanded(child: Text(r, textDirection: TextDirection.rtl)),
              ]),
            )),
          ])),
        ],
        _card(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            const Expanded(child: Text('تاریخچه محلی سیگنال‌ها', style: TextStyle(fontWeight: FontWeight.bold))),
            TextButton(onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove('signal_history');
              setState(() => _history = []);
            }, child: const Text('پاک کردن')),
          ]),
          if (_history.isEmpty) const Text('هنوز تحلیلی ذخیره نشده است.', style: TextStyle(color: Colors.white54)),
          ..._history.take(8).map((raw) {
            try {
              final h = jsonDecode(raw) as Map<String, dynamic>;
              return ListTile(
                dense: true, contentPadding: EdgeInsets.zero,
                title: Text('${h['symbol']} • ${h['timeframe']}'),
                subtitle: Text(h['generatedAt'].toString().replaceFirst('T', ' ').split('.').first),
                trailing: Text(h['direction'].toString(), style: TextStyle(color: _color(h['direction'].toString()), fontWeight: FontWeight.bold)),
              );
            } catch (_) { return const SizedBox.shrink(); }
          }),
        ])),
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: Text(
            'هشدار: این برنامه فقط ابزار تحلیل و تولید سیگنال است و هیچ سفارشی ارسال نمی‌کند. قدرت سیگنال احتمال برد نیست. داده‌ها ممکن است تأخیر داشته باشند؛ قبل از معامله، قیمت و شرایط بروکر را بررسی کنید.',
            textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 11),
          ),
        ),
      ])),
    );
  }

  Widget _pill(String label, String value) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
    decoration: BoxDecoration(color: const Color(0xFF0A1728), borderRadius: BorderRadius.circular(10)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(fontSize: 10, color: Colors.white54)),
      Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
    ]),
  );
}
