import 'package:flutter/material.dart';
import 'models.dart';

class CandleChart extends StatelessWidget {
  final List<Candle> candles;
  const CandleChart({super.key, required this.candles});

  @override
  Widget build(BuildContext context) {
    if (candles.isEmpty) return const SizedBox(height: 180, child: Center(child: Text('داده نمودار موجود نیست')));
    final visible = candles.length > 60 ? candles.sublist(candles.length - 60) : candles;
    return SizedBox(
      height: 210,
      width: double.infinity,
      child: CustomPaint(painter: _CandlePainter(visible, Theme.of(context).colorScheme)),
    );
  }
}

class _CandlePainter extends CustomPainter {
  final List<Candle> data;
  final ColorScheme colors;
  _CandlePainter(this.data, this.colors);

  @override
  void paint(Canvas canvas, Size size) {
    if (data.isEmpty || size.width <= 0 || size.height <= 0) return;
    final minP = data.map((e) => e.low).reduce((a,b) => a < b ? a : b);
    final maxP = data.map((e) => e.high).reduce((a,b) => a > b ? a : b);
    final span = (maxP - minP).abs() < 1e-12 ? 1.0 : maxP - minP;
    const left = 5.0, right = 5.0, top = 8.0, bottom = 8.0;
    final chartH = size.height - top - bottom;
    final step = (size.width - left - right) / data.length;
    final bodyW = (step * .58).clamp(2.0, 12.0).toDouble();
    double y(double p) => top + (maxP - p) / span * chartH;
    final grid = Paint()..color = colors.outline.withOpacity(.18)..strokeWidth = 1;
    for (var k=0;k<4;k++) {
      final gy = top + chartH * k / 3;
      canvas.drawLine(Offset(left,gy), Offset(size.width-right,gy), grid);
    }
    for (var i=0;i<data.length;i++) {
      final c = data[i];
      final x = left + step * (i + .5);
      final up = c.close >= c.open;
      final paint = Paint()
        ..color = up ? const Color(0xFF37D99A) : const Color(0xFFFF657A)
        ..strokeWidth = 1.2;
      canvas.drawLine(Offset(x,y(c.high)), Offset(x,y(c.low)), paint);
      final topY = y(up ? c.close : c.open);
      final bottomY = y(up ? c.open : c.close);
      final rect = Rect.fromLTRB(x-bodyW/2, topY, x+bodyW/2, bottomY == topY ? bottomY+1 : bottomY);
      canvas.drawRect(rect, paint..style=PaintingStyle.fill);
    }
  }

  @override
  bool shouldRepaint(covariant _CandlePainter old) => old.data != data;
}
