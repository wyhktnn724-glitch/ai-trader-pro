import 'dart:convert';
import 'package:http/http.dart' as http;
import 'models.dart';

class MarketDataService {
  static const _binanceSymbols = <String, String>{
    'BTCUSDT': 'BTCUSDT', 'ETHUSDT': 'ETHUSDT',
    'BNBUSDT': 'BNBUSDT', 'SOLUSDT': 'SOLUSDT',
    'XRPUSDT': 'XRPUSDT', 'ADAUSDT': 'ADAUSDT',
  };

  Future<List<Candle>> fetch({
    required String symbol,
    required String timeframe,
    String twelveDataKey = '',
  }) async {
    final normalized = symbol.toUpperCase().replaceAll('/', '');
    if (_binanceSymbols.containsKey(normalized)) {
      return _fetchBinance(normalized, timeframe);
    }
    if (twelveDataKey.trim().isEmpty) {
      throw Exception('برای Forex و طلا، API Key سرویس Twelve Data را در تنظیمات وارد کنید.');
    }
    return _fetchTwelveData(symbol, timeframe, twelveDataKey.trim());
  }

  Future<List<Candle>> _fetchBinance(String symbol, String timeframe) async {
    const intervals = {
      'M1': '1m', 'M5': '5m', 'M15': '15m', 'M30': '30m',
      'H1': '1h', 'H4': '4h', 'D1': '1d',
    };
    final interval = intervals[timeframe];
    if (interval == null) throw Exception('تایم‌فریم پشتیبانی نمی‌شود.');
    final uri = Uri.https('api.binance.com', '/api/v3/klines', {
      'symbol': symbol, 'interval': interval, 'limit': '180',
    });
    final response = await http.get(uri).timeout(const Duration(seconds: 20));
    if (response.statusCode != 200) {
      throw Exception('خطای دریافت داده Binance: HTTP ${response.statusCode}');
    }
    final rows = (jsonDecode(response.body) as List);
    // Exclude the currently forming candle to avoid repainting signals.
    return rows.take(rows.length > 1 ? rows.length - 1 : rows.length).map((row) {
      final r = row as List;
      return Candle(
        time: DateTime.fromMillisecondsSinceEpoch((r[0] as num).toInt(), isUtc: true),
        open: double.parse(r[1].toString()),
        high: double.parse(r[2].toString()),
        low: double.parse(r[3].toString()),
        close: double.parse(r[4].toString()),
        volume: double.parse(r[5].toString()),
      );
    }).toList();
  }

  Future<List<Candle>> _fetchTwelveData(
      String symbol, String timeframe, String key) async {
    const intervals = {
      'M1': '1min', 'M5': '5min', 'M15': '15min', 'M30': '30min',
      'H1': '1h', 'H4': '4h', 'D1': '1day',
    };
    final interval = intervals[timeframe];
    if (interval == null) throw Exception('تایم‌فریم پشتیبانی نمی‌شود.');
    final normalized = symbol.contains('/') ? symbol : _toForexPair(symbol);
    final uri = Uri.https('api.twelvedata.com', '/time_series', {
      'symbol': normalized, 'interval': interval, 'outputsize': '180',
      'apikey': key, 'format': 'JSON',
    });
    final response = await http.get(uri).timeout(const Duration(seconds: 20));
    if (response.statusCode != 200) {
      throw Exception('خطای Twelve Data: HTTP ${response.statusCode}');
    }
    final decoded = jsonDecode(response.body) as Map<String, dynamic>;
    if (decoded.containsKey('status') && decoded['status'] == 'error') {
      throw Exception(decoded['message']?.toString() ?? 'خطای سرویس داده');
    }
    final values = decoded['values'];
    if (values is! List) {
      throw Exception(decoded['message']?.toString() ?? 'داده معتبر دریافت نشد.');
    }
    // Twelve Data returns newest first; skip the still-forming newest bar.
    final completed = values.length > 1 ? values.skip(1) : values;
    final candles = completed.map((item) {
      final v = item as Map<String, dynamic>;
      return Candle(
        time: DateTime.parse(v['datetime'].toString()).toUtc(),
        open: double.parse(v['open'].toString()),
        high: double.parse(v['high'].toString()),
        low: double.parse(v['low'].toString()),
        close: double.parse(v['close'].toString()),
        volume: double.tryParse((v['volume'] ?? '0').toString()) ?? 0,
      );
    }).toList().reversed.toList();
    return candles;
  }

  String _toForexPair(String symbol) {
    final s = symbol.toUpperCase();
    if (s == 'XAUUSD') return 'XAU/USD';
    if (s == 'XAGUSD') return 'XAG/USD';
    if (s.length == 6) return '${s.substring(0, 3)}/${s.substring(3)}';
    return symbol;
  }
}
