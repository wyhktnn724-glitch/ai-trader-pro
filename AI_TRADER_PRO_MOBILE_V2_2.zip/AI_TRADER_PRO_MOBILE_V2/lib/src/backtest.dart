import 'dart:math' as math;
import 'models.dart';
import 'analysis_engine.dart';

class BacktestResult {
  final int trades, wins, losses;
  final double winRate, netReturnPct, profitFactor, maxDrawdownPct;
  final double averageTradePct, feesPct;
  const BacktestResult({
    required this.trades, required this.wins, required this.losses,
    required this.winRate, required this.netReturnPct,
    required this.profitFactor, required this.maxDrawdownPct,
    required this.averageTradePct, required this.feesPct,
  });
}

class Backtester {
  final AnalysisEngine engine;
  Backtester(this.engine);

  /// Signal is evaluated after candle i closes; entry is at candle i+1 open.
  /// Stop/target are checked against subsequent OHLC. If both are touched in
  /// one candle, stop is assumed first (conservative). One position at a time.
  BacktestResult run(
    List<Candle> candles,
    String timeframe, {
    double riskPct = 1.0,
    double roundTripCostPct = 0.08,
    double slippagePct = 0.02,
  }) {
    if (candles.length < 100) {
      throw Exception('بک‌تست حداقل ۱۰۰ کندل می‌خواهد.');
    }
    if (riskPct <= 0 || riskPct > 5) {
      throw Exception('ریسک باید بین ۰.۱ تا ۵ درصد باشد.');
    }
    var equity = 1.0, peak = 1.0, maxDd = 0.0;
    var wins = 0, losses = 0, grossWin = 0.0, grossLoss = 0.0;
    var totalFees = 0.0, sumTradePct = 0.0;
    var i = 70;
    while (i < candles.length - 1) {
      final a = engine.analyse(candles.sublist(i - 70, i + 1), timeframe);
      if (a.direction == 'WAIT' || a.atr <= 0) { i++; continue; }

      final entryBarIndex = i + 1;
      final entryBar = candles[entryBarIndex];
      final entry = entryBar.open * (a.direction == 'BUY'
          ? (1 + slippagePct / 100) : (1 - slippagePct / 100));
      final isLong = a.direction == 'BUY';
      final stop = entry + (isLong ? -1 : 1) * a.atr * 1.5;
      final target = entry + (isLong ? 1 : -1) * a.atr * 2.5;
      final riskDistance = (entry - stop).abs();
      if (riskDistance <= 0 || entry <= 0) { i++; continue; }

      var exit = candles.last.close;
      var exitIndex = candles.length - 1;
      for (var j = entryBarIndex; j < candles.length; j++) {
        final bar = candles[j];
        final stopHit = isLong ? bar.low <= stop : bar.high >= stop;
        final targetHit = isLong ? bar.high >= target : bar.low <= target;
        if (stopHit) {
          exit = stop * (isLong ? (1 - slippagePct / 100) : (1 + slippagePct / 100));
          exitIndex = j; break;
        }
        if (targetHit) {
          exit = target * (isLong ? (1 - slippagePct / 100) : (1 + slippagePct / 100));
          exitIndex = j; break;
        }
      }
      final signedMove = isLong ? exit - entry : entry - exit;
      final grossR = signedMove / riskDistance;
      final costFraction = (roundTripCostPct + 2 * slippagePct) / 100;
      final netR = grossR - (costFraction * entry / riskDistance);
      final tradeReturn = (netR * riskPct / 100).clamp(-1.0, 1.0);
      final feeImpact = costFraction * entry / riskDistance * riskPct;
      totalFees += feeImpact;
      equity *= (1 + tradeReturn);
      sumTradePct += tradeReturn * 100;
      if (tradeReturn > 0) { wins++; grossWin += tradeReturn; }
      else { losses++; grossLoss += tradeReturn.abs(); }
      peak = math.max(peak, equity).toDouble();
      maxDd = math.max(maxDd, (peak - equity) / peak * 100).toDouble();
      // Do not reuse bars that occurred while this position was open.
      i = math.max(i + 1, exitIndex + 1);
    }
    final trades = wins + losses;
    return BacktestResult(
      trades: trades, wins: wins, losses: losses,
      winRate: trades == 0 ? 0 : wins / trades * 100,
      netReturnPct: (equity - 1) * 100,
      profitFactor: grossLoss == 0 ? (grossWin == 0 ? 0 : double.infinity) : grossWin / grossLoss,
      maxDrawdownPct: maxDd,
      averageTradePct: trades == 0 ? 0 : sumTradePct / trades,
      feesPct: totalFees,
    );
  }
}
